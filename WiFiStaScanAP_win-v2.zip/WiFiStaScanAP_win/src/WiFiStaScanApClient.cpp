// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include <iostream>
#include <string>
#include <thread>
#include <vector>
#include <sstream>
#ifndef _WIN32
#include <unistd.h>
#endif

#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/WiFiService/WiFiStaModeProxy.hpp>

using namespace v1::commonapi::WiFiService;



    std::vector<uint8_t> macStringToBytes(const std::string& macStr) {
    std::vector<uint8_t> result;
    std::istringstream iss(macStr);
    std::string token;
    while (std::getline(iss, token, '-')) {
        result.push_back(static_cast<uint8_t>(std::stoi(token, nullptr, 16)));
    }
    return result;
    }



int main() {
    CommonAPI::Runtime::setProperty("LogContext", "E01C");
    CommonAPI::Runtime::setProperty("LogApplication", "E01C");
    CommonAPI::Runtime::setProperty("LibraryBase", "WiFiStaScanAP");

    std::shared_ptr < CommonAPI::Runtime > runtime = CommonAPI::Runtime::get();

    std::string domain = "local";
    std::string instance = "commonapi.WiFiService.WiFiStaMode";
    std::string connection = "client-sample";

    std::shared_ptr<WiFiStaModeProxy<>> myProxy = runtime->buildProxy<WiFiStaModeProxy>(domain,
            instance, connection);

    std::cout << "Checking availability!" << std::endl;
    while (!myProxy->isAvailable())
        std::this_thread::sleep_for(std::chrono::microseconds(10));
    std::cout << "Available..." << std::endl;

    //const std::string name = "World";
    CommonAPI::CallStatus callStatus;
    //std::string returnMessage;
    WiFiStaMode::ReturnEnum_s WiFiError;
    std::vector<WiFiStaMode::ScanApInfo_s> stScanApList_a;
    CommonAPI::CallInfo info(10000);
    info.sender_ = 1234;

    while (true) {

       
       myProxy->vdScanAp(callStatus, WiFiError, stScanApList_a,&info);
        if (callStatus != CommonAPI::CallStatus::SUCCESS) {
            std::cerr << "Remote call failed for vdScanAp!\n";
            return -1;
        }
        
        info.timeout_ = info.timeout_ + 1000;
        std::cout << "ReturnEnum_s WiFiError: '" << static_cast<int>(WiFiError) << "'\n";

        //ham in ra byte///
        // for (const auto& apInfo : stScanApList_a) {
        // auto MACVec = apInfo.getChMacAddr_a();
        // std::cout << "  AP MAC: ";
        // for (size_t i = 0; i < MACVec.size(); ++i) {
        // printf("%02X", MACVec[i]);
        // if (i != MACVec.size() - 1) std::cout << ":";
        // }
        // std::cout << std::endl;
        // }

   
        for (const auto& apInfo : stScanApList_a) {
        std::string macStr = apInfo.getChMacAddr_a(); // Nhận lại string "F4-A4-75-36-5B-6F"
        
        // Parse chuỗi này thành vector<uint8_t>
        std::vector<uint8_t> macVec = macStringToBytes(macStr);

        // In ra MAC
        std::cout << "AP MAC: ";
        for (size_t i = 0; i < macVec.size(); ++i) {
        printf("%02X", macVec[i]);
        if (i != macVec.size() - 1) std::cout << ":";
        }
        std::cout << std::endl;

        std::cout << "UwFreq: " << apInfo.getUwFreq() << std::endl;
        std::cout << "SecurityTypeEnum: " << static_cast<int>(apInfo.getStSecurityTypeEnum()) << std::endl;

    }

}

    return 0;
}
