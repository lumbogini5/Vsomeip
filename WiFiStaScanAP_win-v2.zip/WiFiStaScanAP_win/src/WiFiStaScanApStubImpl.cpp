// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include "WiFiStaScanApStubImpl.hpp"
#include <thread>
using namespace v1_2::commonapi::WiFiService;
 WiFiStaScanApStubImpl:: WiFiStaScanApStubImpl() {
}

 WiFiStaScanApStubImpl::~ WiFiStaScanApStubImpl() {
}


void  WiFiStaScanApStubImpl::vdScanAp(
    const std::shared_ptr<CommonAPI::ClientId> _client,
     vdScanApReply_t _reply)  {

    WiFiStaMode::ReturnEnum_s WiFiError  = WiFiStaMode::ReturnEnum_s::VSOMEIP_ERR_OTHER;
    std::cout << "vdScanAp() called. Return: VSOMEIP_ERR_OTHER" << std::endl;
    //std::this_thread::sleep_for(std::chrono::seconds(5)); 
    std::cout << "error.ModeOn = " << static_cast<int>(WiFiError)  << std::endl;

    std::vector<WiFiStaMode::ScanApInfo_s> stScanApList_a;

    WiFiStaMode::ScanApInfo_s apInfo;

    apInfo.setChMacAddr_a("F4-A4-75-36-5B-6F");
    apInfo.setUwFreq(24);
    apInfo.setStSecurityTypeEnum(WiFiStaMode::SecurityTypeEnum_s::WPA2_PERSONAL);

    stScanApList_a.push_back(apInfo); // hàm push giá trị của vector
    // std::cout << "vdScanAP() called. ScanConfig: " 
    //           << _scanConfig.getScanType() << std::endl;

    // Giả lập thời gian scan

    
    std::this_thread::sleep_for(std::chrono::seconds(2));



    std::cout << "Found " << stScanApList_a.size() << " AP(s). First SSID: " 
              << stScanApList_a.front().getChMacAddr_a() << std::endl;
    std::cout <<"UwFreq:" <<stScanApList_a.front().getUwFreq() << std::endl;
    std::cout <<"StSecurityTypeEnum:" <<static_cast<int>(stScanApList_a.front().getStSecurityTypeEnum()) << std::endl;
    
    //std::cout << "  SSID P2PGoInfo_s stP2PGoInfo: " << stP2PGoInfo.chSsid_a << std::endl;
    //std::cout << "  P2PGoConfig_s UbIpAddr_a: " <<static_cast<int>( _stP2PGOConfig.getUbIpAddr_a()) << std::endl;
    _reply(WiFiError,stScanApList_a);

}

