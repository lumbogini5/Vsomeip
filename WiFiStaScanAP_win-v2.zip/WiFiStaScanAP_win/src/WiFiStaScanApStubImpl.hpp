// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#ifndef WiFiP2PSwitchModeOnSTUBIMPL_HPP_
#define WiFiP2PSwitchModeOnSTUBIMPL_HPP_

#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/WiFiService/WiFiStaModeStubDefault.hpp>

class WiFiStaScanApStubImpl: public v1_2::commonapi::WiFiService::WiFiStaModeStubDefault {

public:
    WiFiStaScanApStubImpl();
    virtual ~WiFiStaScanApStubImpl();

    virtual void vdScanAp(
        const std::shared_ptr<CommonAPI::ClientId> _client,
        vdScanApReply_t _reply
    );



};

#endif // WiFiP2PSwitchModeOnSTUBIMPL_HPP_
