// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include "WiFiStaConnectAPStubImpl.hpp"
#include <thread>
using namespace v1_2::commonapi::WiFiService;
WiFiStaModeStubImpl::WiFiStaModeStubImpl() {
}

WiFiStaModeStubImpl::~WiFiStaModeStubImpl() {
}

void WiFiStaModeStubImpl::vdConnectToAp(
    const std::shared_ptr<CommonAPI::ClientId> _client,
    WiFiStaMode::ConnectApInfo_s _stApInfo,
    WiFiStaMode::IpConfig_s _stIpConfig,
    vdConnectToApReply_t _reply)  {


    //WiFiStaMode::ReturnEnum_s WiFiError;
    int64_t sdConnectionId = -11;
    //WiFiStaMode::IpConfig_s stIpConfig;
    //WiFiStaMode::ConnectApInfo_s stApInfo;



    WiFiStaMode::ReturnEnum_s WiFiError  = WiFiStaMode::ReturnEnum_s::VSOMEIP_ERR_OTHER;

    std::this_thread::sleep_for(std::chrono::seconds(5)); 
     std::cout << "vdConnectToAp() called." << std::endl;


    // std::cout << "vdSwitchStaModeOn() called. Return: VSOMEIP_ERR_OTHER" << std::endl;

    // std::cout << "error.ModeOn = " << static_cast<int>(WiFiError)  << std::endl;


    //std::cout << "  SSID P2PGoInfo_s stP2PGoInfo: " << stP2PGoInfo.chSsid_a << std::endl;
    std::cout << " stApInfo.getChSsid_a " << _stApInfo.getChSsid_a() << std::endl;
    std::cout << " SecurityTypeEnum: '" << static_cast<int>(_stApInfo.getStSecurityTypeEnum()) << "'\n";
    std::cout << " StIpTypeEnum: '" << static_cast<int>(_stIpConfig.getStIpTypeEnum()) << "'\n";
    auto ip = _stIpConfig.getStStaticIpInfo().getUbIpv4Addr_a();
        std::cout << "  Static IP: ";
        for (size_t i = 0; i < ip.size(); ++i) {
            std::cout << (int)ip[i];
            if (i != ip.size() - 1) std::cout << ".";
        }
        std::cout << std::endl;
    
    _reply(WiFiError,sdConnectionId);

}

