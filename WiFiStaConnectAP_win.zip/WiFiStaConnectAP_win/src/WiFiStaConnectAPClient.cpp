// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include <iostream>
#include <string>
#include <thread>

#ifndef _WIN32
#include <unistd.h>
#endif

#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/WiFiService/WiFiStaModeProxy.hpp>

using namespace v1::commonapi::WiFiService;

int main() {
    CommonAPI::Runtime::setProperty("LogContext", "E01C");
    CommonAPI::Runtime::setProperty("LogApplication", "E01C");
    CommonAPI::Runtime::setProperty("LibraryBase", "WiFiStaModeProxy");

    std::shared_ptr < CommonAPI::Runtime > runtime = CommonAPI::Runtime::get();

    std::string domain = "local";
    std::string instance = "commonapi.WiFiService.WiFiStaMode";
    std::string connection = "client-sample";

    std::shared_ptr<WiFiStaModeProxy<>> myProxy = runtime->buildProxy<WiFiStaModeProxy>(domain,
            instance, connection);

    std::cout << "Checking availability!" << std::endl;
    while (!myProxy->isAvailable())
        std::this_thread::sleep_for(std::chrono::microseconds(10));
    std::cout << "Available..." << std::endl;

    //const std::string name = "World";
    CommonAPI::CallStatus callStatus;
    //std::string returnMessage;
    WiFiStaMode::ReturnEnum_s WiFiError;
    WiFiStaMode::ConnectApInfo_s stApInfo;
    WiFiStaMode::IpConfig_s stIpConfig;


    //int64_t sdConnectionId = -11;
    stApInfo.setChSsid_a("TestSSID");
    stApInfo.setStSecurityTypeEnum(WiFiStaMode::SecurityTypeEnum_s::WPA2_PERSONAL);

    stIpConfig.setStIpTypeEnum(WiFiStaMode::IpAddrTypeEnum_s::DHCP);
    //stIpConfig.setStStaticIpInfo().setUbIpv4Addr_a({192, 168, 1, 123});  sai
     WiFiStaMode::StaticIpAddrInfo_s staticIpInfo;
     staticIpInfo.setUbIpv4Addr_a({192, 168, 1, 123});
     stIpConfig.setStStaticIpInfo(staticIpInfo);

    std::int64_t sdConnectionId;
    CommonAPI::CallInfo info(10000);
    info.sender_ = 1234;

    while (true) {

       
       myProxy->vdConnectToAp(stApInfo, stIpConfig, callStatus, WiFiError,  sdConnectionId,&info);
        if (callStatus != CommonAPI::CallStatus::SUCCESS) {
            std::cerr << "Remote call failed for vdConnectToAp!\n";
            return -1;
        }
        
        info.timeout_ = info.timeout_ + 1000;
        std::cout << "ReturnEnum_s WiFiError: '" << static_cast<int>(WiFiError) << "'\n";
        //std::cout << "  stApInfo.getChSsid_a: " << stApInfo.getChSsid_a() << std::endl;
       
        std::cout << "  SdConnectionId: " << sdConnectionId << std::endl;

        //auto ipVec = staticIpInfo.getUbIpv4Addr_a();  // đúng =giống cái dưới
        // auto ipVec = stIpConfig.getStStaticIpInfo().getUbIpv4Addr_a(); // Đúng
        // std::cout << "  staticIpInfo UbIpv4Addr_a: ";
        // for (size_t i = 0; i < ipVec.size(); ++i) {std::cout << static_cast<int>(ipVec[i]);
        // if (i != ipVec.size() - 1) std::cout << ".";} std::cout << std::endl;
    }

    return 0;
}
