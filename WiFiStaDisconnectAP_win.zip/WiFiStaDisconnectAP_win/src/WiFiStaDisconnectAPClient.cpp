// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include <iostream>
#include <string>
#include <thread>

#ifndef _WIN32
#include <unistd.h>
#endif

#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/WiFiService/WiFiStaModeProxy.hpp>

using namespace v1::commonapi::WiFiService;

int main() {
    CommonAPI::Runtime::setProperty("LogContext", "E01C");
    CommonAPI::Runtime::setProperty("LogApplication", "E01C");
    CommonAPI::Runtime::setProperty("LibraryBase", "WiFiStaModeProxy");

    std::shared_ptr < CommonAPI::Runtime > runtime = CommonAPI::Runtime::get();

    std::string domain = "local";
    std::string instance = "commonapi.WiFiService.WiFiStaMode";
    std::string connection = "client-sample";

    std::shared_ptr<WiFiStaModeProxy<>> myProxy = runtime->buildProxy<WiFiStaModeProxy>(domain,
            instance, connection);

    std::cout << "Checking availability!" << std::endl;
    while (!myProxy->isAvailable())
        std::this_thread::sleep_for(std::chrono::microseconds(10));
    std::cout << "Available..." << std::endl;

    //const std::string name = "World";
    CommonAPI::CallStatus callStatus;
    //std::string returnMessage;
    WiFiStaMode::ReturnEnum_s WiFiError;

    CommonAPI::CallInfo info(10000);
    info.sender_ = 1234;

    while (true) {
       myProxy->vdDisconnectToAp(callStatus, WiFiError, &info);
        if (callStatus != CommonAPI::CallStatus::SUCCESS) {
            std::cerr << "Remote call failed for vdDisconnectToAp!\n";
            return -1;
        }
        info.timeout_ = info.timeout_ + 1000;
        std::cout << "vdDisconnectToAp message: '" << static_cast<int>(WiFiError) << "'\n";
       
        //std::this_thread::sleep_for(std::chrono::seconds(2));


    }

    return 0;
}
