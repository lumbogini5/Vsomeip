// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
 
#ifndef WiFiServiceSTUBIMPL_HPP_
#define WiFiServiceSTUBIMPL_HPP_
 
#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/WiFiService/WiFiStaModeStubDefault.hpp>
#include <v1/commonapi/WiFiService/WiFiP2PModeStubDefault.hpp>
 
class WiFiStaModeStubImpl: public v1_2::commonapi::WiFiService::WiFiStaModeStubDefault {
 
public:
   WiFiStaModeStubImpl();
    virtual ~WiFiStaModeStubImpl();
 
 
    virtual void vdSwitchStaModeOn(const std::shared_ptr<CommonAPI::ClientId> _client, vdSwitchStaModeOnReply_t _reply);
    virtual void vdSwitchStaModeOff(const std::shared_ptr<CommonAPI::ClientId> _client, vdSwitchStaModeOffReply_t _reply);
    virtual void incCounter();
    virtual void Counter();
};
 
 
class WiFiP2PModeStubImpl: public v1_2::commonapi::WiFiService::WiFiP2PModeStubDefault {
 
public:
    WiFiP2PModeStubImpl();
    virtual ~WiFiP2PModeStubImpl();
 
    virtual void vdSwitchP2PModeOn(
        const std::shared_ptr<CommonAPI::ClientId> _client,
        v1_2::commonapi::WiFiService::WiFiP2PMode::P2PGoConfig_s _stP2PGOConfig,
        vdSwitchP2PModeOnReply_t _reply
    );
 
};
 
#endif // WiFiServiceSTUBIMPL_HPP_
 

 