// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
 
#include <iostream>
#include <thread>
 
#include <CommonAPI/CommonAPI.hpp>
#include "WiFiServiceStubImpl.hpp"
 
 
using namespace std;
 
int main() {
    CommonAPI::Runtime::setProperty("LogContext", "E01S");
    CommonAPI::Runtime::setProperty("LogApplication", "E01S");
    CommonAPI::Runtime::setProperty("LibraryBase", "WiFiService");
 
    std::shared_ptr<CommonAPI::Runtime> runtime = CommonAPI::Runtime::get();
 
    std::string domain = "local";
    std::string instanceWiFiStaMode = "commonapi.WiFiService.WiFiStaMode";
    std::string instanceWiFiP2PMode = "commonapi.WiFiService.WiFiP2PMode";
    std::string connection = "service-sample";
 
    std::shared_ptr<WiFiStaModeStubImpl> WiFiStaModeService = std::make_shared<WiFiStaModeStubImpl>();
    std::shared_ptr<WiFiP2PModeStubImpl> WiFiP2PModeService = std::make_shared<WiFiP2PModeStubImpl>();
 
    bool WiFiStaModesuccessfullyRegistered = runtime->registerService(domain, instanceWiFiStaMode, WiFiStaModeService, connection);
    bool WiFiP2PModesuccessfullyRegistered = runtime->registerService(domain, instanceWiFiP2PMode, WiFiP2PModeService, connection);
 
    while (!WiFiStaModesuccessfullyRegistered) {
        std::cout << "Register OffService failed, trying again in 100 milliseconds..." << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        WiFiStaModesuccessfullyRegistered = runtime->registerService(domain, instanceWiFiStaMode, WiFiStaModeService, connection);
    }
 
    while (!WiFiP2PModesuccessfullyRegistered) {
        std::cout << "Register OnService failed, trying again in 100 milliseconds..." << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        WiFiP2PModesuccessfullyRegistered = runtime->registerService(domain, instanceWiFiP2PMode, WiFiP2PModeService, connection);
    }
 
    // while (!OffsuccessfullyRegistered || !OnsuccessfullyRegistered) {
    //     if(!OffsuccessfullyRegistered){
    //        // std::cout << "Register OffService failed, trying again in 100 milliseconds..." << std::endl;
    //         std::this_thread::sleep_for(std::chrono::milliseconds(100));
    //         OffsuccessfullyRegistered = runtime->registerService(domain, instanceOff, OffService, connection);
    //     }
    //     if(!OnsuccessfullyRegistered){
    //        // std::cout << "Register OnService failed, trying again in 100 milliseconds..." << std::endl;
    //         std::this_thread::sleep_for(std::chrono::milliseconds(100));
    //         OnsuccessfullyRegistered = runtime->registerService(domain, instanceOn, OnService, connection);
 
    //     }
 
    // }
 
 
    std::cout << "Successfully Registered all Service!" << std::endl;
 
    while (true) {
 
         WiFiStaModeService->incCounter();
         WiFiStaModeService->Counter();
        std::cout << "Waiting for calls... (Abort with CTRL+C)" << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
 
    return 0;
}
 