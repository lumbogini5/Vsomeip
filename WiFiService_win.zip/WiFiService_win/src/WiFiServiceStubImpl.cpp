// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
 
#include "WiFiServiceStubImpl.hpp"
#include <thread>
using namespace v1_2::commonapi::WiFiService;
WiFiStaModeStubImpl::WiFiStaModeStubImpl() {
}
 
WiFiStaModeStubImpl::~WiFiStaModeStubImpl() {
}
 
void WiFiStaModeStubImpl::vdSwitchStaModeOn(const std::shared_ptr<CommonAPI::ClientId> _client,
        vdSwitchStaModeOnReply_t _reply) {
 
   WiFiStaMode::ReturnEnum_s WiFiErrorWiFiStaMode  = WiFiStaMode::ReturnEnum_s::VSOMEIP_ERR_OTHER;
    std::cout << "vdSwitchStaModeOn() called. Return: VSOMEIP_ERR_OTHER" << std::endl;
 
    std::this_thread::sleep_for(std::chrono::seconds(5));
 
    std::cout << "error.vdSwitchStaModeOn = " << static_cast<int>(WiFiErrorWiFiStaMode)  << std::endl;
 
 
   
    _reply(WiFiErrorWiFiStaMode);
 
};
 
void WiFiStaModeStubImpl::vdSwitchStaModeOff(const std::shared_ptr<CommonAPI::ClientId> _client,
        vdSwitchStaModeOffReply_t _reply) {
 
   WiFiStaMode::ReturnEnum_s WiFiErrorWiFiStaMode  = WiFiStaMode::ReturnEnum_s::VSOMEIP_ERR_WRONG_STATE;
    std::cout << "vdSwitchStaModeOff() called. Return: VSOMEIP_ERR_WRONG_STATE" << std::endl;
 
    std::this_thread::sleep_for(std::chrono::seconds(5));
 
    std::cout << "error.vdSwitchStaModeOff= " << static_cast<int>(WiFiErrorWiFiStaMode)  << std::endl;
 
 
   
    _reply(WiFiErrorWiFiStaMode);
 
};
 
void WiFiStaModeStubImpl::incCounter() {
    std::cout << "enter incCounter function" << "\n" ;
   
    WiFiStaMode::ConnectStatusInfo_s stConnectStatusInfo ;
 
    stConnectStatusInfo.setEStatus(WiFiStaMode::WiFiStaStatusEnum_s::OFF);
    stConnectStatusInfo.setBlIsConnected(false); // false =0 true =1
    stConnectStatusInfo.setEFreq(WiFiStaMode::WiFiFreqEnum_s::FREQ_6_0);
    stConnectStatusInfo.setStSecurityTypeEnum( WiFiStaMode::SecurityTypeEnum_s::WPA3_ENTERPRISE);
    stConnectStatusInfo.setSwRssi(-40);
    stConnectStatusInfo.setChSsid_a("SAM_SS1224");
    stConnectStatusInfo.setUbSsidLen(stConnectStatusInfo.getChSsid_a().length());
    stConnectStatusInfo.setChPassword_a("12345678");
    stConnectStatusInfo.setUbPasswordLen(stConnectStatusInfo.getChPassword_a().length());
   
 
    std::cout << "Received EStatus event: " <<  static_cast<int> (stConnectStatusInfo.getEStatus()) << std::endl;
    std::cout << "Received BlIsConnected event: "  << (stConnectStatusInfo.getBlIsConnected()) << std::endl;
    std::cout << "Received EFreq event: " <<  static_cast<int> (stConnectStatusInfo.getEFreq()) << std::endl;
    std::cout << "Received SecurityTypeEnum event: " <<  static_cast<int> (stConnectStatusInfo.getStSecurityTypeEnum()) << std::endl;
    std::cout << "Received SwRssi event: "  << (stConnectStatusInfo.getSwRssi()) << std::endl;
    std::cout << "Received ChSsid_a event: "  << (stConnectStatusInfo.getChSsid_a()) << std::endl;
    std::cout << "Received UbSsidLen event: "  << ((int)stConnectStatusInfo.getUbSsidLen()) << std::endl;
    std::cout << "Received ChPassword_a event: "  << (stConnectStatusInfo.getChPassword_a()) << std::endl;
    std::cout << "Received UbPasswordLen event: "  << ((int)stConnectStatusInfo.getUbPasswordLen()) << std::endl;
    //std::cout << "Received status event ConnectReturnEnum_s : '" << static_cast<int>(stRet) << "'\n";
    fireConectionStatusEvent(stConnectStatusInfo);
}
 
void WiFiStaModeStubImpl::Counter() {
    std::cout << "enter Counter function" << "\n" ;
    int64_t sdConnectionId =11;
    WiFiStaMode::ConnectReturnEnum_s stRet =  WiFiStaMode::ConnectReturnEnum_s::AP_CONNECT_FAIL ;
    std::cout << "Received status event: " << sdConnectionId << std::endl;
    std::cout << "Received status event ConnectReturnEnum_s : '" << static_cast<int>(stRet) << "'\n";
    fireApConnectionResultEvent((int64_t) sdConnectionId, stRet);
}
   
 
 
WiFiP2PModeStubImpl::WiFiP2PModeStubImpl() {
}
 
WiFiP2PModeStubImpl::~WiFiP2PModeStubImpl() {
}
 
void WiFiP2PModeStubImpl::vdSwitchP2PModeOn(
    const std::shared_ptr<CommonAPI::ClientId> _client,
   WiFiP2PMode::P2PGoConfig_s _stP2PGOConfig,
    vdSwitchP2PModeOnReply_t _reply)  {

 
   WiFiP2PMode::ReturnEnum_s WiFiErrorWiFiP2PMode  = WiFiP2PMode::ReturnEnum_s::VSOMEIP_ERR_OTHER;
   WiFiP2PMode::P2PGoInfo_s stP2PGoInfo;
    stP2PGoInfo.setChSsid_a("test");
    stP2PGoInfo.setUbIpAddr_a({192, 168, 49, 10});
    std::cout << "vdSwitchStaModeOn() called. Return: VSOMEIP_ERR_OTHER" << std::endl;

    std::this_thread::sleep_for(std::chrono::seconds(5)); 

    std::cout << "error.ModeOn = " << static_cast<int>(WiFiErrorWiFiP2PMode)  << std::endl;
    //std::cout << "  SSID P2PGoInfo_s stP2PGoInfo: " << stP2PGoInfo.chSsid_a << std::endl;
    std::cout << "  P2PGoConfig_s ChSsid: " << _stP2PGOConfig.getChSsid() << std::endl;
    std::cout << "  P2PGoConfig_s EFreq: " <<static_cast<int>( _stP2PGOConfig.getEFreq()) << std::endl;
    //std::cout << "  P2PGoConfig_s UbIpAddr_a: " <<static_cast<int>( _stP2PGOConfig.getUbIpAddr_a()) << std::endl;
    _reply(WiFiErrorWiFiP2PMode,stP2PGoInfo);

 
};