// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
 
#include <iostream>
#include <string>
#include <thread>
 
#ifndef _WIN32
#include <unistd.h>
#endif
 
#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/WiFiService/WiFiStaModeProxy.hpp>
#include <v1/commonapi/WiFiService/WiFiP2PModeProxy.hpp>
 
using namespace v1::commonapi::WiFiService;
 
int main() {
    CommonAPI::Runtime::setProperty("LogContext", "E01C");
    CommonAPI::Runtime::setProperty("LogApplication", "E01C");
    CommonAPI::Runtime::setProperty("LibraryBase", "WiFiService");
 
    std::shared_ptr < CommonAPI::Runtime > runtime = CommonAPI::Runtime::get();
 
    std::string domain = "local";
    std::string instanceWiFiStaMode = "commonapi.WiFiService.WiFiStaMode";
    std::string instanceWiFiP2PMode = "commonapi.WiFiService.WiFiP2PMode";
    std::string connection = "client-sample";
 
    std::shared_ptr<WiFiStaModeProxy<>> StaModeProxy = runtime->buildProxy<WiFiStaModeProxy>(domain,
            instanceWiFiStaMode, connection);
 
    std::shared_ptr<WiFiP2PModeProxy<>> P2PModeProxy = runtime->buildProxy<WiFiP2PModeProxy>(domain,
            instanceWiFiP2PMode, connection);
 
    std::cout << "Checking availability WiFiStaMode interface!" << std::endl;
    while (!StaModeProxy->isAvailable())
        std::this_thread::sleep_for(std::chrono::microseconds(10));
    std::cout << "WiFiStaMode ineterface Available..." << std::endl;
 
 
    std::cout << "Checking availability WiFiP2PMode interface!" << std::endl;
    while (!P2PModeProxy->isAvailable())
        std::this_thread::sleep_for(std::chrono::microseconds(10));
    std::cout << "WiFiP2PMode ineterface Available..." << std::endl;
 
 
    //const std::string name = "World";
    CommonAPI::CallStatus callStatus;
    //std::string returnMessage;
    WiFiStaMode::ReturnEnum_s WiFiErrorWiFiStaMode;
    
 
    CommonAPI::CallInfo info(10000);
    info.sender_ = 1234;
 
 
    StaModeProxy->getConectionStatusEvent().subscribe([&](WiFiStaMode::ConnectStatusInfo_s stConnectStatusInfo){
           
        //std::this_thread::sleep_for(std::chrono::seconds(2));
        std::cout << "Received EStatus event  : '" <<  static_cast<int>(stConnectStatusInfo.getEStatus()) << "'\n";
        std::cout << "Received BlIsConnected event: "  << (stConnectStatusInfo.getBlIsConnected()) << std::endl;
        std::cout << "Received EFreq event  : '" <<  static_cast<int>(stConnectStatusInfo.getEFreq()) << "'\n";
        std::cout << "Received SecurityTypeEnum event: " <<  static_cast<int> (stConnectStatusInfo.getStSecurityTypeEnum()) << std::endl;
        std::cout << "Received SwRssi event: "  << (stConnectStatusInfo.getSwRssi()) << std::endl;
        std::cout << "Received ChSsid_a event: "  << (stConnectStatusInfo.getChSsid_a()) << std::endl;
        std::cout << "Received UbSsidLen event: "  << ((int)stConnectStatusInfo.getUbSsidLen()) << std::endl;
        std::cout << "Received ChPassword_a event: "  << (stConnectStatusInfo.getChPassword_a()) << std::endl;
        std::cout << "Received UbPasswordLen event: "  << ((int)stConnectStatusInfo.getUbPasswordLen()) << std::endl;
 
       std::cout << "out of phase ConectionStatusEvent : '" << "'\n";
           
        });  
 
 
    StaModeProxy->getApConnectionResultEvent().subscribe([&](std::int64_t sdConnectionId, WiFiStaMode::ConnectReturnEnum_s stRet){
           
        std::cout << "Received status event ConnectID: " << (int64_t) sdConnectionId << std::endl;
        //std::this_thread::sleep_for(std::chrono::seconds(2));
        std::cout << "Received status event ConnectReturnEnum_s : '" << static_cast<int>(stRet) << "'\n";
         std::cout << "out of phase ApConnectionResultEvent : '" << "'\n";
           
        });    
 

    
     
    std::thread t1([&](){
    while (true) {
       StaModeProxy->vdSwitchStaModeOn(callStatus, WiFiErrorWiFiStaMode, &info);
        if (callStatus != CommonAPI::CallStatus::SUCCESS) {
            std::cerr << "Remote call failed for  WiFiStaMode vdSwitchStaModeOn !\n";
            return -1;
        }
        info.timeout_ = info.timeout_ + 1000;
        std::cout << "vdSwitchStaModeOn message: '" << static_cast<int>(WiFiErrorWiFiStaMode) << "'\n";

        StaModeProxy->vdSwitchStaModeOff(callStatus, WiFiErrorWiFiStaMode, &info);
        if (callStatus != CommonAPI::CallStatus::SUCCESS) {
            std::cerr << "Remote call failed for  WiFiStaMode vdSwitchStaModeOn !\n";
            return -1;
        }
        info.timeout_ = info.timeout_ + 1000;
        std::cout << "vdSwitchStaModeOff message: '" << static_cast<int>(WiFiErrorWiFiStaMode) << "'\n";


        }
                });
        //std::this_thread::sleep_for(std::chrono::seconds(2));
 
    WiFiP2PMode::ReturnEnum_s WiFiErrorWiFiP2PMode;
    WiFiP2PMode::P2PGoInfo_s stP2PGoInfo;
    WiFiP2PMode::P2PGoConfig_s stP2PGOConfig;
    stP2PGOConfig.setChSsid("TestSSID");
    stP2PGOConfig.setEFreq( WiFiP2PMode::WiFiFreqEnum_s::FREQ_2_4);
    
    std::thread t2([&](){
    while(true){
        P2PModeProxy->vdSwitchP2PModeOn(stP2PGOConfig, callStatus, WiFiErrorWiFiP2PMode, stP2PGoInfo,&info);
        if (callStatus != CommonAPI::CallStatus::SUCCESS) {
        std::cerr << "Remote call failed for vdSwitchStaModeOn!\n";
        return -1;
         }
 
        std::cout << "ReturnEnum_s WiFiError: '" << static_cast<int>(WiFiErrorWiFiP2PMode) << "'\n";
        std::cout << "  SSID P2PGoInfo_s ChSsid_a: " << stP2PGoInfo.getChSsid_a() << std::endl;
       // std::cout << "  SSID P2PGoInfo_s setUbIpAddr_a: " << stP2PGoInfo.getUbIpAddr_a() << std::endl;
        //std::this_thread::sleep_for(std::chrono::seconds(2));
        auto ipVec = stP2PGoInfo.getUbIpAddr_a();
        std::cout << "  SSID P2PGoInfo_s setUbIpAddr_a: ";
        for (size_t i = 0; i < ipVec.size(); ++i) {std::cout << static_cast<int>(ipVec[i]);
        if (i != ipVec.size() - 1) std::cout << ".";} std::cout << std::endl;
        //std::this_thread::sleep_for(std::chrono::seconds(1));
    }
            });
 
t1.join();
t2.join();
 
    return 0;
}
 