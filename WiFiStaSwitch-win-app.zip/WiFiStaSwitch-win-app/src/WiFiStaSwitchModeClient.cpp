// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include <iostream>
#include <string>
#include <thread>

#ifndef _WIN32
#include <unistd.h>
#endif

#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/examples/WiFiStaSwitchModeProxy.hpp>

using namespace v1::commonapi::examples;

int main() {
    CommonAPI::Runtime::setProperty("LogContext", "E01C");
    CommonAPI::Runtime::setProperty("LogApplication", "E01C");
    CommonAPI::Runtime::setProperty("LibraryBase", "WiFiStaSwitchMode");

    std::shared_ptr < CommonAPI::Runtime > runtime = CommonAPI::Runtime::get();

    std::string domain = "local";
    std::string instance = "commonapi.examples.StaSwitchMode";
    std::string connection = "client-sample";

    std::shared_ptr<WiFiStaSwitchModeProxy<>> myProxy = runtime->buildProxy<WiFiStaSwitchModeProxy>(domain,
            instance, connection);

    std::cout << "Checking availability!" << std::endl;
    while (!myProxy->isAvailable())
        std::this_thread::sleep_for(std::chrono::microseconds(10));
    std::cout << "Available..." << std::endl;

    //const std::string name = "World";
    CommonAPI::CallStatus callStatus;
    //std::string returnMessage;
    WiFiStaSwitchMode::ReturnEnum_s WiFiError;

    CommonAPI::CallInfo info(10000);
    info.sender_ = 1234;

    while (true) {

        std::cout << "Nhap so 1 de bat WiFiStaMode, nhap so 2 de tat WiFiStaMode, nhap so khac de thoat: ";
        int choice;
        std::cin >> choice;
        //std::string choice;
       // std::cin >> choice;
        //if (choice== "wifi1")
        
        switch(choice){
            case 1:
                    myProxy->vdSwitchStaModeOn(callStatus, WiFiError, &info);
                    if (callStatus != CommonAPI::CallStatus::SUCCESS) {
                    std::cerr << "Remote call failed for vdSwitchStaModeOn!\n";
                    return -1;
                    }
                    //info.timeout_ = info.timeout_ + 1000;
                    std::cout << "On message: '" << static_cast<int>(WiFiError) << "'\n";
        
            break;        
       
        //std::this_thread::sleep_for(std::chrono::seconds(2));

            case 2:
        //else if(choice == "wifi2"){
                    myProxy->vdSwitchStaModeOff(callStatus, WiFiError, &info);
                    if (callStatus != CommonAPI::CallStatus::SUCCESS) {
                    std::cerr << "Remote call failed for vdSwitchStaModeOff!\n";
                    return -1;
                    }

                    std::cout << "Off message: '" << static_cast<int>(WiFiError) << "'\n";
            break;
         default:

                     std::this_thread::sleep_for(std::chrono::seconds(1)); 
        }

    }

    return 0;
}
