// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include "WiFiStaSwitchModeStubImpl.hpp"
#include <thread>
#include <yaml-cpp/yaml.h>
#include <cstdint>
#include <map>
#include <string>
using namespace v1_2::commonapi::examples;

//hàm map data file yaml để gửi cho client ví dụ gọi biến mode_on_return:"VSOMEIP_ERR_OTHER"
//thì service sẽ gửi WiFiStaSwitchMode::ReturnEnum_s::VSOMEIP_OK cho client
static std::map<std::string, WiFiStaSwitchMode::ReturnEnum_s> returnEnumMap = {
    {"VSOMEIP_ERR_OTHER", WiFiStaSwitchMode::ReturnEnum_s::VSOMEIP_OK},
    {"VSOMEIP_ERR_WRONG_STATE", WiFiStaSwitchMode::ReturnEnum_s::VSOMEIP_ERR_WRONG_STATE}
    // Thêm các giá trị khác nếu có
    };
WiFiStaSwitchModeStubImpl::WiFiStaSwitchModeStubImpl() {
}

WiFiStaSwitchModeStubImpl::~WiFiStaSwitchModeStubImpl() {
}

    
    

void WiFiStaSwitchModeStubImpl::vdSwitchStaModeOn(const std::shared_ptr<CommonAPI::ClientId> _client,
        vdSwitchStaModeOnReply_t _reply) {
    //WiFiStaSwitchMode::ReturnEnum_s WiFiError  = WiFiStaSwitchMode::ReturnEnum_s::VSOMEIP_ERR_OTHER;        
    WiFiStaSwitchMode::ReturnEnum_s WiFiError;
    YAML::Node config = YAML::LoadFile("WiFi-Status.yaml"); // đọc từ file yaml
    std::string modeOnStr = config["mode_on_return"].as<std::string>(); // đọc biến string "mode_on_return"
    auto it = returnEnumMap.find(modeOnStr);
     if (it != returnEnumMap.end()) {
        WiFiError = it->second;
    }

    int64_t myValue = config["my_value"].as<int64_t>(); // đọc biến "my_value" tring file yaml
    std::cout << "myValue = " << myValue << std::endl;

    std::vector<uint8_t> ubIpv4Addr_a;
    for (const auto& val : config["ubIpv4Addr_a"]) {
        ubIpv4Addr_a.push_back(val.as<uint8_t>());
    }
    std::cout << "ubIpv4Addr_a: ";
    for (auto vec : ubIpv4Addr_a) {
        std::cout << static_cast<int>(vec) << " ";
    } 
    std::cout << std::endl;
    
    std::cout << "vdSwitchStaModeOn() called. Return: VSOMEIP_ERR_OTHER" << std::endl;

    //std::this_thread::sleep_for(std::chrono::seconds(5)); 
    std::cout << "vdSwitchStaModeOn() called. Return: " << modeOnStr << std::endl;

    std::cout << "error.ModeOn = " << static_cast<int>(WiFiError)  << std::endl;


    
    _reply(WiFiError);

};

void WiFiStaSwitchModeStubImpl::vdSwitchStaModeOff(const std::shared_ptr<CommonAPI::ClientId> _client,
    vdSwitchStaModeOffReply_t _reply) {

    
    WiFiStaSwitchMode::ReturnEnum_s WiFiError = WiFiStaSwitchMode::ReturnEnum_s::VSOMEIP_ERR_WRONG_STATE;
    std::cout << "vdSwitchStaModeOff() called. Return: VSOMEIP_ERR_WRONG_STATE" << std::endl;

     //std::this_thread::sleep_for(std::chrono::seconds(5)); 

    
    std::cout << "error.ModeOff = " << static_cast<int>(WiFiError) << std::endl;

    _reply(WiFiError);
}
