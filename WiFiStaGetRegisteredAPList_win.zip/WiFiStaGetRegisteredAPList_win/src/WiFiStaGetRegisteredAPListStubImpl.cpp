// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include "WiFiStaGetRegisteredAPListStubImpl.hpp"
#include <thread>
using namespace v1_2::commonapi::WiFiService;
 WiFiStaModeStubImpl:: WiFiStaModeStubImpl() {
}

 WiFiStaModeStubImpl::~ WiFiStaModeStubImpl() {
}


void  WiFiStaModeStubImpl::vdGetRegisteredAPList(
    const std::shared_ptr<CommonAPI::ClientId> _client,
      vdGetRegisteredAPListReply_t _reply)  {

    WiFiStaMode::ReturnEnum_s WiFiError  = WiFiStaMode::ReturnEnum_s::VSOMEIP_ERR_OTHER;
    std::cout << "vdGetRegisteredAPList() called. Return: VSOMEIP_ERR_OTHER" << std::endl;
    //std::this_thread::sleep_for(std::chrono::seconds(5)); 
    std::cout << "error.vdGetRegisteredAPList = " << static_cast<int>(WiFiError)  << std::endl;

    std::vector<WiFiStaMode::RegisteredApInfo_s> stRegisteredApList_a;

    WiFiStaMode::RegisteredApInfo_s apInfo;

    apInfo.setChSsid_a("TestSSID RegisteredApList");
    apInfo.setStSecurityTypeEnum(WiFiStaMode::SecurityTypeEnum_s::WPA2_PERSONAL);

    stRegisteredApList_a.push_back(apInfo); // hàm push giá trị của vector
    // std::cout << "vdScanAP() called. ScanConfig: " 
    //           << _scanConfig.getScanType() << std::endl;

    // Giả lập thời gian scan

    
    std::this_thread::sleep_for(std::chrono::seconds(2));



    std::cout << "Found " << stRegisteredApList_a.size() << " AP(s). First SSID: " 
              << stRegisteredApList_a.front().getChSsid_a() << std::endl;
    std::cout <<"StSecurityTypeEnum:" <<static_cast<int>(stRegisteredApList_a.front().getStSecurityTypeEnum()) << std::endl;
    
    //std::cout << "  SSID P2PGoInfo_s stP2PGoInfo: " << stP2PGoInfo.chSsid_a << std::endl;
    //std::cout << "  P2PGoConfig_s UbIpAddr_a: " <<static_cast<int>( _stP2PGOConfig.getUbIpAddr_a()) << std::endl;
    _reply(WiFiError,stRegisteredApList_a);

}

