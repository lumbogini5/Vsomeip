// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include "WiFiP2PSwitchModeOnStubImpl.hpp"
#include <thread>
using namespace v1_2::commonapi::WiFiService;
WiFiP2PSwitchModeOnStubImpl::WiFiP2PSwitchModeOnStubImpl() {
}

WiFiP2PSwitchModeOnStubImpl::~WiFiP2PSwitchModeOnStubImpl() {
}

void WiFiP2PSwitchModeOnStubImpl::vdSwitchP2PModeOn(
    const std::shared_ptr<CommonAPI::ClientId> _client,
    WiFiP2PSwitchModeOn::P2PGoConfig_s _stP2PGOConfig,
    vdSwitchP2PModeOnReply_t _reply)  {

    WiFiP2PSwitchModeOn::ReturnEnum_s WiFiError  = WiFiP2PSwitchModeOn::ReturnEnum_s::VSOMEIP_ERR_OTHER;
    WiFiP2PSwitchModeOn::P2PGoInfo_s stP2PGoInfo;
    stP2PGoInfo.setChSsid_a("test");
    stP2PGoInfo.setUbIpAddr_a({192, 168, 49, 10});
    std::cout << "vdSwitchStaModeOn() called. Return: VSOMEIP_ERR_OTHER" << std::endl;

    std::this_thread::sleep_for(std::chrono::seconds(5)); 

    std::cout << "error.ModeOn = " << static_cast<int>(WiFiError)  << std::endl;
    //std::cout << "  SSID P2PGoInfo_s stP2PGoInfo: " << stP2PGoInfo.chSsid_a << std::endl;
    std::cout << "  P2PGoConfig_s ChSsid: " << _stP2PGOConfig.getChSsid() << std::endl;
    std::cout << "  P2PGoConfig_s EFreq: " <<static_cast<int>( _stP2PGOConfig.getEFreq()) << std::endl;
    //std::cout << "  P2PGoConfig_s UbIpAddr_a: " <<static_cast<int>( _stP2PGOConfig.getUbIpAddr_a()) << std::endl;
    _reply(WiFiError,stP2PGoInfo);

}

