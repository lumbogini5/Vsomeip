// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include <iostream>
#include <string>
#include <thread>

#ifndef _WIN32
#include <unistd.h>
#endif

#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/WiFiService/WiFiP2PSwitchModeOnProxy.hpp>

using namespace v1::commonapi::WiFiService;

int main() {
    CommonAPI::Runtime::setProperty("LogContext", "E01C");
    CommonAPI::Runtime::setProperty("LogApplication", "E01C");
    CommonAPI::Runtime::setProperty("LibraryBase", "WiFiP2PSwitchModeOnProxy");

    std::shared_ptr < CommonAPI::Runtime > runtime = CommonAPI::Runtime::get();

    std::string domain = "local";
    std::string instance = "commonapi.WiFiService.WiFiP2PSwitchModeOn";
    std::string connection = "client-sample";

    std::shared_ptr<WiFiP2PSwitchModeOnProxy<>> myProxy = runtime->buildProxy<WiFiP2PSwitchModeOnProxy>(domain,
            instance, connection);

    std::cout << "Checking availability!" << std::endl;
    while (!myProxy->isAvailable())
        std::this_thread::sleep_for(std::chrono::microseconds(10));
    std::cout << "Available..." << std::endl;

    //const std::string name = "World";
    CommonAPI::CallStatus callStatus;
    //std::string returnMessage;
    WiFiP2PSwitchModeOn::ReturnEnum_s WiFiError;
    WiFiP2PSwitchModeOn::P2PGoInfo_s stP2PGoInfo;
    WiFiP2PSwitchModeOn::P2PGoConfig_s stP2PGOConfig;
    stP2PGOConfig.setChSsid("TestSSID");
    stP2PGOConfig.setEFreq( WiFiP2PSwitchModeOn::WiFiFreqEnum_s::FREQ_2_4);
    CommonAPI::CallInfo info(10000);
    info.sender_ = 1234;

    while (true) {

       
       myProxy->vdSwitchP2PModeOn(stP2PGOConfig, callStatus, WiFiError, stP2PGoInfo,&info);
        if (callStatus != CommonAPI::CallStatus::SUCCESS) {
            std::cerr << "Remote call failed for vdSwitchP2PModeOn!\n";
            return -1;
        }
        
        info.timeout_ = info.timeout_ + 1000;
        std::cout << "ReturnEnum_s WiFiError: '" << static_cast<int>(WiFiError) << "'\n";
        std::cout << "  SSID P2PGoInfo_s ChSsid_a: " << stP2PGoInfo.getChSsid_a() << std::endl;
       // std::cout << "  SSID P2PGoInfo_s setUbIpAddr_a: " << stP2PGoInfo.getUbIpAddr_a() << std::endl;
        //std::this_thread::sleep_for(std::chrono::seconds(2));
        auto ipVec = stP2PGoInfo.getUbIpAddr_a();
        std::cout << "  SSID P2PGoInfo_s setUbIpAddr_a: ";
        for (size_t i = 0; i < ipVec.size(); ++i) {std::cout << static_cast<int>(ipVec[i]);
        if (i != ipVec.size() - 1) std::cout << ".";} std::cout << std::endl;
    }

    return 0;
}
