// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#ifndef  WiFiStaModeSTUBIMPL_HPP_
#define  WiFiStaModeSTUBIMPL_HPP_

#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/WiFiService/WiFiStaModeStubDefault.hpp>

class WiFiStaModeStubImpl: public v1_2::commonapi::WiFiService::WiFiStaModeStubDefault {

public:
    WiFiStaModeStubImpl();
    virtual ~WiFiStaModeStubImpl();

    virtual void vdDeleteRegisteredAP(const std::shared_ptr<CommonAPI::ClientId> _client, std::string _chSsid_a, vdDeleteRegisteredAPReply_t _reply);

    virtual void vdDeleteAllAP(const std::shared_ptr<CommonAPI::ClientId> _client, vdDeleteAllAPReply_t _reply);

};

#endif //  WiFiStaModeSTUBIMPL_HPP_
