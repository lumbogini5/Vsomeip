// Copyright (C) 2014-2019 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include "WiFiStaDeleteAPStubImpl.hpp"
#include <thread>
using namespace v1_2::commonapi::WiFiService;
WiFiStaModeStubImpl::WiFiStaModeStubImpl() {
}

WiFiStaModeStubImpl::~WiFiStaModeStubImpl() {
}

void WiFiStaModeStubImpl::vdDeleteRegisteredAP(const std::shared_ptr<CommonAPI::ClientId> _client,std::string _chSsid_a,
        vdDeleteRegisteredAPReply_t _reply) {

    WiFiStaMode::ReturnEnum_s WiFiError  = WiFiStaMode::ReturnEnum_s::VSOMEIP_ERR_OTHER;
    std::cout << "vdDeleteRegisteredAPReply_t() called. Return: VSOMEIP_ERR_OTHER" << std::endl;

    std::this_thread::sleep_for(std::chrono::seconds(5)); 

    std::cout << "error.vdDeleteRegisteredAPReply_t = " << static_cast<int>(WiFiError)  << std::endl;

    std::cout << "chSsid_a = " << _chSsid_a  << std::endl;


    
    _reply(WiFiError);

};

void WiFiStaModeStubImpl::vdDeleteAllAP(const std::shared_ptr<CommonAPI::ClientId> _client,
    vdDeleteAllAPReply_t _reply) {

    
   WiFiStaMode::ReturnEnum_s WiFiError = WiFiStaMode::ReturnEnum_s::VSOMEIP_ERR_WRONG_STATE;
    std::cout << "vdDeleteAllAP() called. Return: VSOMEIP_ERR_WRONG_STATE" << std::endl;

     std::this_thread::sleep_for(std::chrono::seconds(5)); 

    
    std::cout << "error.vdDeleteAllAP = " << static_cast<int>(WiFiError) << std::endl;

    _reply(WiFiError);
}
